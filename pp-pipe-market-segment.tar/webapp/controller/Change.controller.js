
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/format/DateFormat",
    'sap/ui/core/Fragment',
    "../util/util",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/core/BusyIndicator',
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    'sap/m/SearchField',
    'sap/ui/model/type/String',
    'sap/ui/table/Column',
    'sap/m/Column',
    'sap/m/Text',
    'sap/m/Label'

],
    function (Controller, DateFormat, Fragment, util, Filter, FilterOperator, BusyIndicator,
        MessageToast, MessageBox, SearchField, TypeString, UIColumn, MColumn, Text, Label) {
        "use strict";

        return Controller.extend("com.wl.pp.zppmksgpr.controller.Change", {
            onInit: function () {
                this._pValueHelpDialog = {};
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteChange").attachPatternMatched(this._onObjectMatched, this);
            },
            // function to display data on screen load based on filter
            _onObjectMatched: function (oEvent) {
                this.getView().getModel("localModel").setProperty("/DeletedData", []);
                // Get the current date and time
                var oCurrentDate = new Date();
                // Format the date and time
                var oDateFormat = DateFormat.getDateTimeInstance({ pattern: "MM/dd/yyyy" });
                var oTimeFormat = DateFormat.getDateTimeInstance({ pattern: "HH:mm:ss" });
                var sFormattedDate = oDateFormat.format(oCurrentDate);
                var sFormattedTime = oTimeFormat.format(oCurrentDate);
                this.getView().getModel("localModel").setProperty("/date", sFormattedDate);
                this.getView().getModel("localModel").setProperty("/time", sFormattedTime);
                var aFilter = this.getView().getModel("localModel").getProperty("/ChangeFilter");
                // if (aFilter && aFilter.length > 0) {
                var oDataModel = this.getView().getModel();
                oDataModel.read("/ZZ1_ZPP_PIPE_MARKET", {
                    filters: aFilter,
                    success: function (oData, oHeader) {
                        var aChangeData = oData.results || [];
                        this.getView().getModel("localModel").setProperty("/ChangeData", aChangeData);
                        this.getView().getModel("localModel").setProperty("/totalRecords", aChangeData.length);
                        this.getView().getModel("localModel").refresh(true);
                    }.bind(this),
                    error: function (oError) {
                        this.getView().getModel("localModel").setProperty("/totalRecords", "0");
                        MessageToast.show("error");
                    }.bind(this)
                });
                //}
            },

            onAddPress: function () {
                var oChangeData = this.getView().getModel("localModel").getProperty("/ChangeData");
                oChangeData.push({
                    "ID": "",
                    "Plant": "",
                    "Material": "",
                    "Material Description": "",
                    "Pipe Market": "",
                    "Message": "",
                    "IsNew": true,
                    "IsDeleted": false,
                    "IsUpdated": false
                });
                this.getView().getModel("localModel").setProperty("/ChangeData", oChangeData);
            },
            onPlantValueHelpRequested: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext("localModel").getPath()
                this.getView().getModel("localModel").setProperty("/Valuehelp/Src", sPath);
                this.getView().getModel("localModel").setProperty("/Valuehelp/Field", "Plant");
                this._handleValueHelp("com.wl.pp.zppmksgpr.fragment.PlantlSearchHelpChange", "Plant");

            },
            onMaterialValueHelpRequested: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext("localModel").getPath()
                this.getView().getModel("localModel").setProperty("/Valuehelp/Src", sPath);
                this.getView().getModel("localModel").setProperty("/Valuehelp/Field", "Material");
                //this._onValueHelpRequested("com.wl.pp.zppmksgpr.fragment.MaterialSearchHelp", "Material", "Material");
                this._handleValueHelp("com.wl.pp.zppmksgpr.fragment.MaterialSearchHelpChange", "Material");
            },
            _handleValueHelp: function (sFragmentName, sKey) {
                var oView = this.getView();
                if (!this._pValueHelpDialog[sFragmentName]) {
                    this._pValueHelpDialog[sFragmentName] = Fragment.load({
                        id: oView.getId(),
                        name: sFragmentName,
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }
                this._pValueHelpDialog[sFragmentName].then(function (oValueHelpDialog) {
                    //this._configValueHelpDialog();
                    var oLocalModel = this.getView().getModel("localModel");
                    var aFilter = oLocalModel.getProperty("/ChangeFilter");
                    var aPlantFilter = aFilter.filter(row => row.sPath === "Plant");

                    if (sKey === "Plant") {
                        if (aPlantFilter && aPlantFilter.length > 0) {
                            oValueHelpDialog.getBinding("items").filter(aPlantFilter);
                        }
                    }
                    else if (aFilter && aFilter.length > 0) {
                        oValueHelpDialog.getBinding("items").filter(aFilter);
                    }

                    oValueHelpDialog.open();
                }.bind(this));
            },

            handleValueHelpClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                if (oSelectedItem) {
                    var sSelectedPath = oSelectedItem.getBindingContext().getPath(),
                        oSelectedData = this.getView().getModel().getProperty(sSelectedPath),
                        sPath = this.getView().getModel("localModel").getProperty("/Valuehelp/Src"),
                        sField = this.getView().getModel("localModel").getProperty("/Valuehelp/Field");
                    this.getView().getModel("localModel").setProperty((sPath + "/" + sField), oSelectedData[sField]);
                    if (sField === "Material") {
                        this.getView().getModel("localModel").setProperty((sPath + "/MaterialDescription"), oSelectedData["Material_Text"]);
                    }
                }

            },
            onDeletePress: function () {
                var oTable = this.byId("IDChangeTable");
                var aSelectedContexts = oTable.getSelectedContexts("localModel");

                if (!aSelectedContexts && aSelectedContexts.length <= 0) {
                    MessageToast.show("Please select a row to delete");
                    return;
                }
                var self = this;
                MessageBox.confirm("Do you want to delete the Row ?", {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                            var oModel = this.getView().getModel("localModel");
                            aSelectedContexts.forEach(selectedContext => {
                                var sPath = selectedContext.getPath();
                                var aDeletedData = oModel.getProperty("/DeletedData");
                                var oDelRecord = oModel.getProperty(sPath);
                                oDelRecord.IsDeleted = true;
                                aDeletedData.push(oModel.getProperty(sPath));
                                var iIndex = parseInt(sPath.split("/").pop());
                                var aData = oModel.getProperty("/ChangeData");
                                // Remove the selected item from the array
                                aData.splice(iIndex, 1);
                                // Update the model with the new data
                                oModel.setProperty("/ChangeData", aData);
                                // Clear selection
                                oTable.removeSelections();
                                // MessageToast.show("Item deleted successfully");
                            }, this);

                        }
                    }.bind(this),
                    dependentOn: this.getView()
                });
            },
            // handler function to display confirmation before data is submitted to api
            onSaveBtnPress: function () {
                MessageBox.confirm("Do you want to save the changes ?", {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                            this._onSavePress();
                        }
                    }.bind(this),
                    dependentOn: this.getView()
                });
            },
            // handler function to send payload to api to save the changes in change table

            _onSavePress: function () {
                BusyIndicator.show();
                var oLocalModel = this.getView().getModel("localModel");
                var oChangeData = this.getView().getModel("localModel").getProperty("/ChangeData");
                var oDataModel = this.getView().getModel();
                oDataModel.setDeferredGroups(["postCallsGroup"]);
                var bChangeExists = false,
                    bDeleteExists = false;
                if (oChangeData && oChangeData.length > 0) {
                    var aUpdatedRecord = oChangeData.filter(row => row.IsNew || row.IsUpdated)
                    //var aUpdatedRecord = oChangeData;
                    if (aUpdatedRecord && aUpdatedRecord.length > 0) {
                        bChangeExists = true;
                        aUpdatedRecord.forEach(function (row) {
                            oDataModel.create("/ZPP_CDS_PIPE_MARKET",
                                {
                                    Plant: row.Plant,
                                    Material: row.Material,
                                    PipeMarket: row.PipeMarket,
                                    Action: row.IsNew ? "C" : "U"
                                }
                                , {
                                    groupId: "postCallsGroup",
                                    success: function (response) {
                                        console.log("success!");
                                    },
                                    error: function (error) {
                                        console.log("error!");
                                    }
                                });
                        });


                    }
                }

                if (oLocalModel.getProperty("/DeletedData") && oLocalModel.getProperty("/DeletedData").length > 0) {
                    bDeleteExists = this._onDelete(oDataModel, oLocalModel);
                }
                if (bChangeExists || bDeleteExists) {
                    oDataModel.submitChanges({
                        groupId: "postCallsGroup",
                        success: function (oData) {
                            BusyIndicator.hide();
                            console.log("success");
                            // this._setUpdatedData(oData);
                            this._onObjectMatched();
                            util.currentFormattedDate(this.getView().getModel("localModel"));
                            //this.getView().getModel("localModel").setProperty("/totalRecords", aTableData.length);

                            if (oData.__batchResponses[0] && oData.__batchResponses[0]["__changeResponses"]) {
                                var nSuccess = 0, nError = 0;
                                var aChangeData = oData.__batchResponses[0] && oData.__batchResponses[0]["__changeResponses"];
                                aChangeData.forEach(row => {
                                    if (row.data.status === "E")
                                        nError = nError + 1;
                                    else
                                        nSuccess = nSuccess + 1;

                                });

                                MessageToast.show(`Data Updated Successfully : ${nSuccess} \n Data Not Updated Successfully : ${nError}`);

                            }
                            //MessageToast.show("Data Updated Successfully");

                        }.bind(this),
                        error: function (oResponse) {
                            BusyIndicator.hide();
                            console.log("error");
                        }.bind(this)
                    });
                }
            },
            _onDelete: function (oDataModel, oLocalModel) {
                //call delete apis
                var aDeletedData = oLocalModel.getProperty("/DeletedData");
                var bDelete = false;
                aDeletedData = aDeletedData.filter(oRow => !oRow.isNew);
                bDelete = aDeletedData.length > 0 ? true : false;
                aDeletedData.forEach(row => {
                    var sEntityPath = "/ZZ1_ZPP_PIPE_MARKET(guid'" + row.SAP_UUID + "')";
                    oDataModel.remove(sEntityPath);
                });
                return bDelete
            },
            //function to set data to create data
            _setUpdatedData: function (oData) {
                var aResponseData = oData.__batchResponses[0].__changeResponses;
                var aTableData = aResponseData.map(oResponse => {
                    console.log(oResponse.data);
                    return oResponse.data
                });
                this.getView().getModel("localModel").setProperty("/ChangeData", aTableData);
                util.currentFormattedDate(this.getView().getModel("localModel"));
                this.getView().getModel("localModel").setProperty("/totalRecords", aTableData.length);


            },
            // handler function on change of Pipemarket value change
            onPipeMarketChange: function (oEvent) {
                var oPath = oEvent.getSource().getBindingContext("localModel").getPath();
                var oChangedRow = this.getView().getModel("localModel").getProperty(oPath);
                if (!oChangedRow.isNew) {
                    oChangedRow.IsUpdated = true;
                }
            },
            // function to search the plant material in search help
            handlePMSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value"),
                    aFilters = [new Filter({
                        filters: [
                            new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sValue }),
                            new Filter({ path: "Material", operator: FilterOperator.Contains, value1: sValue })
                        ],
                        and: false
                    })];
                var oBinding = oEvent.getSource().getBinding("items");
                oBinding.filter(aFilters);
            },

            onRefreshPress: function () {
                BusyIndicator.show();
                this._onObjectMatched();
                BusyIndicator.hide();
            },
            onSearchPress: function (oEvent) {
                var sSearchValue = oEvent.getParameter("query"),
                    aFilters = [new Filter({
                        filters: [
                            new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchValue }),
                            new Filter({ path: "Material", operator: FilterOperator.Contains, value1: sSearchValue })
                        ],
                        and: false
                    })];

                var oBinding = this.byId("IDChangeTable").getBinding("items");
                oBinding.filter(aFilters);

            },
            // function to download the excel file
            onDownload: function () {
                var aData = this.getView().getModel("localModel").getProperty("/ChangeData");
                const mappedData = aData.map(record => ({
                    Plant: record.Plant,
                    Material: record.Material,
                    MaterialDescription: record.MaterialDescription,
                    PipeMarket: record.PipeMarket,
                    SAP_CreatedByUser_Text: record.SAP_CreatedByUser_Text,
                    SAP_CreatedDateTime: new Date(record.SAP_CreatedDateTime),
                    SAP_LastChangedByUser_Text: record.SAP_LastChangedByUser_Text,
                    SAP_LastChangedDateTime: new Date(record.SAP_LastChangedDateTime)

                }));


                var aColumns = [

                    { label: "Plant", property: "Plant", type: "string" },
                    { label: "Material", property: "Material", type: "string" },
                    { label: "Material Description", property: "MaterialDescription", type: "string" },
                    { label: "Pipe Market", property: "PipeMarket", type: "string" },
                    { label: "Created By", property: "SAP_CreatedByUser_Text", type: "string" },
                    { label: "Created Date", property: "SAP_CreatedDateTime", type: "date" },
                    { label: "Last Changed By", property: "SAP_LastChangedByUser_Text", type: "string" },
                    { label: "Last Changed Date", property: "SAP_LastChangedDateTime", type: "date" }
                ];

                // Create the settings for the Spreadsheet
                var oSettings = {
                    workbook: { columns: aColumns },
                    dataSource: mappedData,
                    fileName: "ChangeData.xlsx",
                    worker: false // Use a web worker for export; set to false for simplicity
                };
                util.excelDownload(oSettings);

            },
            // Function to display Material value help popup 
            onMaterialValuehelpRequested_NEW: function (oEvent) {
                this._onValueHelpRequested("com.wl.pp.zppmksgpr.fragment.MaterialSearchHelp", "Material", "Material");
                this.getView().getModel("localModel").setProperty("/SelectedId", oEvent.getSource().getId());
            },
            _onValueHelpRequested: function (sFragmentName, sKey, sLabel) {
                this._oBasicSearchField = new SearchField();
                this.loadFragment({
                    name: sFragmentName
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();
                    this._oVHD = oDialog;
                    this.getView().addDependent(oDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oDialog.setRangeKeyFields([
                        {
                            label: sLabel,
                            key: sKey,
                            type: "string",
                            typeInstance: new TypeString({}, {
                                maxLength: 10
                            })
                        }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(this._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {
                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            oTable.bindAggregation("rows", {
                                path: "/I_MaterialPlant",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            if (sKey === "Material") {
                                this._addColumn("{Material}", "Material", oTable)
                                this._addColumn("{Material_Text}", "Material Description", oTable)
                                this._addColumn("{Plant}", "Plant", oTable);
                            }
                            else {
                                this._addColumn("{Plant}", "Plant", oTable);
                            }

                        }

                        // For Mobile the default table is sap.m.Table
                        if (oTable.bindItems) {
                            // Bind items to the ODataModel and add columns
                            oTable.bindAggregation("items", {
                                path: "/ZEWM_PLANTMATERIAL_CDS",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{Plant}" }), new Label({ text: "{Material}" }), new Label({ text: "{Material_Text}" })]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            if (sKey === "Material") {

                                oTable.addColumn(new MColumn({ header: new Label({ text: "Material" }) }));
                                oTable.addColumn(new MColumn({ header: new Label({ text: "Material Description" }) }));
                                oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
                            }
                            else {
                                oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));

                            }

                        }
                        oDialog.update();
                    }.bind(this));
                    oDialog.open();
                }.bind(this));
            },
            // function to add the column to inputted table object with the input column details
            _addColumn: function (sColumnName, sColumnText, oTable) {
                var oColumn = new UIColumn({ label: new Label({ text: sColumnText }), template: new Text({ wrapping: false, text: sColumnName }) });
                oColumn.data({
                    fieldName: sColumnName
                });
                oTable.addColumn(oColumn);
            },
            //function to filter the table in the valuehelp based on the inputted search string in filter bar 
            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Material", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Material_Text", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            //funtion to filter the value help table based on the inputted filter object
            _filterTable: function (oFilter) {
                var oVHD = this._oVHD;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },
            //function to set the tokens to the source of the multi input which triggerred value help open event
            onValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this.getView().byId(this.getView().getModel("localModel").getProperty("/SelectedId")).setTokens(aTokens);
                this._oVHD.close();
            },
            // function to close the value help
            onValueHelpCancelPress: function () {
                this._oVHD.close();
            },
            // function to destroy  the value help after the value help is closed
            onValueHelpAfterClose: function () {
                this._oVHD.destroy();
            }


        });
    });

