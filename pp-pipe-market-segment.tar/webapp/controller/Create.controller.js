
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "../util/util"
],
    function (Controller, formatter, util) {
        "use strict";

        return Controller.extend("com.wl.pp.zppmksgpr.controller.Create", {
            formatter: formatter,
            onInit: function () {

            },

            // function to download the excel file
            onDownload: function () {
                var aData = this.getView().getModel("localModel").getProperty("/CreateData");
                const mappedData = aData.map(record => ({
                    Plant: record.Plant,
                    Material: record.Material,
                    MaterialDescription: record.MaterialDescription,
                    PipeMarket: record.PipeMarket,
                    MESSAGE: record.MESSAGE

                }));




                var aColumns = [

                    { label: "Plant", property: "Plant", type: "string" },
                    { label: "Material", property: "Material", type: "string" },
                    { label: "Material Description", property: "MaterialDescription", type: "string" },
                    { label: "Pipe Market", property: "PipeMarket", type: "string" },
                    { label: "Message", property: "MESSAGE", type: "string" }];


                // Create the settings for the Spreadsheet
                var oSettings = {
                    workbook: { columns: aColumns },
                    dataSource: mappedData,
                    fileName: "CreateData.xlsx",
                    worker: false // Use a web worker for export; set to false for simplicity
                };
                util.excelDownload(oSettings);

            }
        });
    });

