sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    'sap/m/SearchField',
    'sap/ui/model/type/String',
    'sap/ui/table/Column',
    'sap/m/Column',
    'sap/m/Text',
    'sap/m/Label',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "../util/util",
    'sap/ui/core/BusyIndicator'


], function (Controller, MessageToast, MessageBox, SearchField, TypeString,
    UIColumn, MColumn, Text, Label, Filter, FilterOperator, util, BusyIndicator
) {
    "use strict";

    return Controller.extend("com.wl.pp.zppmksgpr.controller.Main", {


        onInit: function () {
            this._oValueHelpDialog = {};
        },
        //function to identify the selected mode
        onModeSelectChange: function (oEvent) {
            var nSelectedIndex = oEvent.getParameter("selectedIndex");
            var mode = nSelectedIndex === 0 ? "Create" : "Change";
            this.getView().getModel("localModel").setProperty("/mode", mode);
        },
        //save file contents on file change if its of .txt type
        onFileUpload: function (oEvent) {
            if (oEvent && oEvent.getSource()) {

                var oFile = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
                if (oFile && oFile.type === "text/plain") {
                    this._oFile = oFile;

                }
            }
        },
        onExecutePress: function (oEvent) {
            switch (this.getView().getModel("localModel").getProperty("/mode")) {
                case "Create": {
                    BusyIndicator.show();

                    //read file
                    if (this._oFile) {
                        try {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                var fileContent = e.target.result;
                                var oModel = this.getView().getModel("localModel");
                                var parsedData = this.parseFileContent(fileContent, oModel.getProperty("/isHdrSelected"));
                                // Create a JSON model and bind it to the table                                         
                                oModel.setProperty("/parsedData", parsedData);

                                //OData POST call

                                var oDataModel = this.getView().getModel();
                                oDataModel.setDeferredGroups(["postCallsGroup"]);
                                if (parsedData && parsedData.length > 0) {
                                    parsedData.forEach(function (row) {
                                        oDataModel.create("/ZPP_CDS_PIPE_MARKET", row, {
                                            groupId: "postCallsGroup",
                                            success: function (response) {
                                                console.log("api call successful!");
                                            },
                                            error: function (error) {
                                                console.log("api call failed.");
                                            }
                                        });
                                    });

                                    oDataModel.submitChanges({
                                        groupId: "postCallsGroup",
                                        success: function (oData) {
                                            console.log("success");
                                            var bResponse = this._setCreateData(oData);
                                            if (bResponse) {
                                                var oRouter = this.getOwnerComponent().getRouter();
                                                oRouter.navTo("RouteCreate");
                                            }
                                            BusyIndicator.hide();
                                        }.bind(this),
                                        error: function (oResponse) {
                                            BusyIndicator.hide();
                                            console.log("error");
                                        }.bind(this)
                                    });
                                }

                            }.bind(this);

                        } catch (error) {

                            MessageToast.show("Incorrect Tab Separator in File");
                            BusyIndicator.hide();

                        }


                        reader.readAsText(this._oFile);
                    } else {
                        MessageToast.show("No file selected for upload.");
                    }

                    break;
                }
                case "Change": {
                    var oMaterialInput = this.getView().byId("idmaterialStart"),
                        aMatToken = oMaterialInput.getTokens(),
                        oPlantInput = this.getView().byId("idPlantStart"),
                        aPlantToken = oPlantInput.getTokens();
                    var aFilter = [];
                    // if (!aMatToken || !aPlantToken) {
                    //     MessageToast.show("No Filters selected");

                    // } else {

                    aMatToken.forEach(token => {
                        var oFilter = this._formFilter(token, "Material");
                        if (oFilter)
                            aFilter.push(oFilter);
                    });
                    aPlantToken.forEach(token => {
                        var oFilter = this._formFilter(token, "Plant");
                        if (oFilter)
                            aFilter.push(oFilter);
                    });

                    this.getView().getModel("localModel").setProperty("/ChangeFilter", aFilter);
                    if (!aFilter || aFilter.length <= 0) {
                        if (oMaterialInput.getValue() || oPlantInput.getValue()) {
                            if (oMaterialInput.getValue())
                                aFilter.push(
                                    new Filter({
                                        path: "Material",
                                        operator: FilterOperator.EQ,
                                        value1: oMaterialInput.getValue().toUpperCase()
                                    }));
                            if (oPlantInput.getValue())
                                aFilter.push(new Filter({
                                    path: "Plant",
                                    operator: FilterOperator.EQ,
                                    value1: oPlantInput.getValue().toUpperCase()
                                }));
                            this.getView().getModel("localModel").setProperty("/ChangeFilter", aFilter);
                        }




                        //     }

                        //     else {
                        //         MessageToast.show("Material or Plant cannot be empty");
                        //     }
                        // } else {
                        //     var oRouter = this.getOwnerComponent().getRouter();
                        //     oRouter.navTo("RouteChange");
                        // }
                    }
                    this._checkDataExists(this.getView().getModel("localModel").getProperty("/ChangeFilter"), this.getView().getModel());
                    break;
                }
            }


        },
        _checkDataExists: function (aFilter, oDataModel) {
            oDataModel.read("/ZZ1_ZPP_PIPE_MARKET/$count", {
                filters: aFilter,
                success: function (oData, oHeader) {
                    if (parseInt(oData) > 0) {
                        var oRouter = this.getOwnerComponent().getRouter();
                        oRouter.navTo("RouteChange");
                    }
                    else {
                        MessageToast.show("No Data found");
                    }

                }.bind(this),
                error: function (oError) {

                    MessageToast.show("error");
                }.bind(this)
            });
        },
        //function to form filter cndition 
        _formFilter: function (oToken, sFieldPath) {
            var oFilterObj = {};
            var sKeyType = oToken.getAggregation("customData")[0].getProperty("key");
            switch (sKeyType) {
                case "row": {
                    oFilterObj = new Filter({
                        path: sFieldPath,
                        operator: FilterOperator.Contains,
                        value1: oToken.getKey()
                    });
                    break;
                }
                case "range": {
                    var oValue = oToken.getAggregation("customData")[0].getProperty("value");
                    oFilterObj = new Filter({
                        path: oValue.keyField,
                        operator: FilterOperator[oValue.operation],
                        value1: oValue.value1,
                        value2: oValue.value2
                    });
                }
            }
            return oFilterObj;
        },
        // function to parse format the the file content of txt file to json
        parseFileContent: function (fileContent, bIncludesHdr) {
            try {
                // Split the content by lines
                var lines = fileContent.split("\n");

                // Remove the header line if header checkbox is checked
                var dataLines = bIncludesHdr ? lines.slice(1) : lines;

                var data = [];
                dataLines.forEach(function (line) {
                    var fields = line.split("\t");
                    if (fields.length > 1) { // Ensure the line has data

                        var aPlantVal = fields[0].length > 4 ? fields[0].slice(0, 4) : fields[0].trim();
                        data.push({
                            Plant: aPlantVal,
                            Material: fields[1].trim(),
                            PipeMarket: fields[2].trim(),
                            Action: "C"
                        });
                    }
                });

                return data;

            } catch (error) {
                MessageToast.show("Incorrect Tab Separator in File");
                BusyIndicator.hide();
            }

        },

        // Function to display Material value help popup 
        onMaterialValuehelpRequested: function (oEvent) {
            this._onValueHelpRequested("com.wl.pp.zppmksgpr.fragment.MaterialSearchHelp", "Material", "Material");
            this.getView().getModel("localModel").setProperty("/SelectedId", oEvent.getSource().getId());
        },
        // Function to display Plant value help popup 
        onPlantValuehelpRequested: function (oEvent) {
            this._onValueHelpRequested("com.wl.pp.zppmksgpr.fragment.PlantSearchHelp", "Plant", "Plant");
            this.getView().getModel("localModel").setProperty("/SelectedId", oEvent.getSource().getId());

        },
        // Function to display  value help popup  with input : fragment name, key column and Label
        _onValueHelpRequested: function (sFragmentName, sKey, sLabel) {
            this.getView().getModel("localModel").setProperty("/SelectedKey", sKey);
            this._oBasicSearchField = new SearchField();
            this.loadFragment({
                name: sFragmentName
            }).then(function (oDialog) {
                var oFilterBar = oDialog.getFilterBar();
                this._oVHD = oDialog;
                this.getView().addDependent(oDialog);

                // Set key fields for filtering in the Define Conditions Tab
                oDialog.setRangeKeyFields([
                    {
                        label: sLabel,
                        key: sKey,
                        type: "string",
                        typeInstance: new TypeString({}, {
                            maxLength: 10
                        })
                    }]);

                // Set Basic Search for FilterBar
                oFilterBar.setFilterBarExpanded(false);
                oFilterBar.setBasicSearch(this._oBasicSearchField);

                // Trigger filter bar search when the basic search is fired
                this._oBasicSearchField.attachSearch(function () {
                    oFilterBar.search();
                });

                oDialog.getTableAsync().then(function (oTable) {
                    // For Desktop and tabled the default table is sap.ui.table.Table
                    if (oTable.bindRows) {
                        // Bind rows to the ODataModel and add columns
                        oTable.bindAggregation("rows", {
                            path: sKey === "Material" ? "/I_MaterialPlant" : "/I_Plant",
                            events: {
                                dataReceived: function () {
                                    oDialog.update();
                                }
                            }
                        });
                        if (sKey === "Material") {
                            this._addColumn("{Material}", "Material", oTable)
                            this._addColumn("{Material_Text}", "Material Description", oTable)
                            this._addColumn("{Plant}", "Plant", oTable);
                        }
                        else {
                            this._addColumn("{Plant}", "Plant", oTable);
                            this._addColumn("{PlantName}", "Plant Description", oTable);
                        }

                    }

                    // For Mobile the default table is sap.m.Table
                    if (oTable.bindItems) {
                        // Bind items to the ODataModel and add columns
                        oTable.bindAggregation("items", {
                            path: "/ZEWM_PLANTMATERIAL_CDS",
                            template: new ColumnListItem({
                                cells: [new Label({ text: "{Plant}" }), new Label({ text: "{Material}" }), new Label({ text: "{Material_Text}" })]
                            }),
                            events: {
                                dataReceived: function () {
                                    oDialog.update();
                                }
                            }
                        });
                        if (sKey === "Material") {

                            oTable.addColumn(new MColumn({ header: new Label({ text: "Material" }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: "Material Description" }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
                        }
                        else {
                            oTable.addColumn(new MColumn({ header: new Label({ text: "Plant" }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: "Plant Description" }) }));


                        }

                    }
                    oDialog.update();
                }.bind(this));
                oDialog.open();
            }.bind(this));
        },
        // function to add the column to inputted table object with the input column details
        _addColumn: function (sColumnName, sColumnText, oTable) {
            var oColumn = new UIColumn({ label: new Label({ text: sColumnText }), template: new Text({ wrapping: false, text: sColumnName }) });
            oColumn.data({
                fieldName: sColumnName
            });
            oTable.addColumn(oColumn);
        },
        //function to filter the table in the valuehelp based on the inputted search string in filter bar 
        onFilterBarSearch: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            if (this.getView().getModel("localModel").getProperty("/SelectedKey") === "Material") {

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Material", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Material_Text", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));
            }
            else if (this.getView().getModel("localModel").getProperty("/SelectedKey") === "Plant") {
                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Plant", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "PlantName", operator: FilterOperator.Contains, value1: sSearchQuery })

                    ],
                    and: false
                }));

            }

            this._filterTable(new Filter({
                filters: aFilters,
                and: true
            }));
        },
        //funtion to filter the value help table based on the inputted filter object
        _filterTable: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },
        //function to set the tokens to the source of the multi input which triggerred value help open event
        onValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            this.getView().byId(this.getView().getModel("localModel").getProperty("/SelectedId")).setTokens(aTokens);
            this._oVHD.close();
        },
        // function to close the value help
        onValueHelpCancelPress: function () {
            this._oVHD.close();
        },
        // function to destroy  the value help after the value help is closed
        onValueHelpAfterClose: function () {
            this._oVHD.destroy();
        },
        //function to set data to create data
        _setCreateData: function (oData) {
            var bReturn = true;
            try {
                if (oData.__batchResponses && oData.__batchResponses[0] && oData.__batchResponses[0].__changeResponses) {
                    var aResponseData = oData.__batchResponses[0].__changeResponses;
                    var aTableData = aResponseData.map(oResponse => {
                        return oResponse.data
                    });
                    this.getView().getModel("localModel").setProperty("/CreateData", aTableData);
                    util.currentFormattedDate(this.getView().getModel("localModel"));
                    this.getView().getModel("localModel").setProperty("/totalRecords", aTableData.length);

                }
                else if (oData.__batchResponses && oData.__batchResponses[0] && oData.__batchResponses[0].response && oData.__batchResponses[0].response.body) {
                    var sErrMessage = oData.__batchResponses[0].response.body;
                    console.log(sErrMessage);
                    MessageBox.error(sErrMessage);
                    bReturn = false;

                }
            }
            catch (e) {
                BusyIndicator.hide();
                bReturn = false;
            }


            return bReturn;

        },
        handleTypeMissmatch: function (oEvent) {
            MessageBox.error("The file type is not supported. Please upload the correct file format: txt");
        }



    });

});

