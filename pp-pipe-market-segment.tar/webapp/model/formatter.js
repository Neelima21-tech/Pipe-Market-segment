sap.ui.define([], () => {
    "use strict";
    return {
           statusIcon(sMsg) {
                  var sIconSrc = "";
                  if (sMsg === "Record Created Successfully") {
                         sIconSrc = "sap-icon://message-success";
                  }
                  else {
                         sIconSrc = "sap-icon://message-error";
                  }
                  return sIconSrc;

           },
           statusColor(sMsg) {
                  var sIconColor = "";
                  if (sMsg === "Record Created Successfully") {
                         sIconColor = "Success";
                  }
                  else {
                         sIconColor = "Error";
                  }
                  return sIconColor;

           }
    };
});