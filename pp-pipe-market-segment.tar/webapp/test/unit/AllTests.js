sap.ui.define([
	"comwlpp/zppmksgpr/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
