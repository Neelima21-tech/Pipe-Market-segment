sap.ui.define(["sap/ui/core/format/DateFormat", "sap/ui/export/Spreadsheet"], (DateFormat,Spreadsheet) => {
    "use strict";

    return {
           currentFormattedDate(oModel) {
                  // Get the current date and time
                  var oCurrentDate = new Date();
                  // Format the date and time
                  var oDateFormat = DateFormat.getDateTimeInstance({ pattern: "MM/dd/yyyy" });
                  var oTimeFormat = DateFormat.getDateTimeInstance({ pattern: "HH:mm:ss" });
                  var sFormattedDate = oDateFormat.format(oCurrentDate);
                  var sFormattedTime = oTimeFormat.format(oCurrentDate);
                  oModel.setProperty("/date", sFormattedDate);
                  oModel.setProperty("/time", sFormattedTime);
                  oModel.refresh(true);
           },

           excelDownload: function(oSettings){
                  // Create and build the spreadsheet
             var oSpreadsheet = new Spreadsheet(oSettings);
             oSpreadsheet.build()
             .then(function () {
                 MessageToast.show("Spreadsheet export has finished");
             })
             .finally(function () {
                 oSpreadsheet.destroy();
             });
           }

    };
});